#ifndef TRAP_H
#define TRAP_H
#include "defs.h"
#include "types.h"

struct pushregs {
    uintptr zero;  // Hard-wired zero
    uintptr ra;    // Return address
    uintptr sp;    // Stack pointer
    uintptr gp;    // Global pointer
    uintptr tp;    // Thread pointer
    uintptr t0;    // Temporary
    uintptr t1;    // Temporary
    uintptr t2;    // Temporary
    uintptr s0;    // Saved register/frame pointer
    uintptr s1;    // Saved register
    uintptr a0;    // Function argument/return value
    uintptr a1;    // Function argument/return value
    uintptr a2;    // Function argument
    uintptr a3;    // Function argument
    uintptr a4;    // Function argument
    uintptr a5;    // Function argument
    uintptr a6;    // Function argument
    uintptr a7;    // Function argument
    uintptr s2;    // Saved register
    uintptr s3;    // Saved register
    uintptr s4;    // Saved register
    uintptr s5;    // Saved register
    uintptr s6;    // Saved register
    uintptr s7;    // Saved register
    uintptr s8;    // Saved register
    uintptr s9;    // Saved register
    uintptr s10;   // Saved register
    uintptr s11;   // Saved register
    uintptr t3;    // Temporary
    uintptr t4;    // Temporary
    uintptr t5;    // Temporary
    uintptr t6;    // Temporary
};

struct trapframe {
    struct pushregs gpr;
    uintptr status;
    uintptr epc;
    uintptr stval;
    uintptr cause;
};

// 异常信息结构体
struct exception_info {
    uint64 cause;
    uint64 epc;
    int handled;
};

#define MAX_EXCEPTIONS 16

// 函数声明
void kernel_trap_init(void);
void init_interrupt(void);
void print_trapframe(struct trapframe *tf);
void print_regs(struct pushregs *gpr);
void handle_interrupt(struct trapframe *tf);
void handle_exception(struct trapframe *tf);
void trap(struct trapframe *tf);
void process_pending_exceptions(void);  // 新增：处理待打印的异常

// 中断优先级定义
#define PRIORITY_LOWEST        0
#define PRIORITY_LOW           1
#define PRIORITY_MEDIUM        2
#define PRIORITY_HIGH          3
#define PRIORITY_HIGHEST       4

// 时钟中断相关
void timer_init();
void timer_set_next();
uint64 get_time_ms();

// 外部中断相关
void plic_init();
void plic_enable(int irq);
void uart_intr_init();

// 全局变量声明
extern volatile struct exception_info exception_buffer[MAX_EXCEPTIONS];
extern volatile int exception_head;
extern volatile int exception_tail;
extern volatile uint64 timer_ticks;

enum Exception {
	InstructionMisaligned = 0,
	InstructionAccessFault = 1,
	IllegalInstruction = 2,
	Breakpoint = 3,
	LoadMisaligned = 4,
	LoadAccessFault = 5,
	StoreMisaligned = 6,
	StoreAccessFault = 7,
	UserEnvCall = 8,
	SupervisorEnvCall = 9,
	MachineEnvCall = 11,
	InstructionPageFault = 12,
	LoadPageFault = 13,
	StorePageFault = 15,
};

enum Interrupt {
	UserSoft = 0,
	SupervisorSoft,
	UserTimer = 4,
	SupervisorTimer,
	UserExternal = 8,
	SupervisorExternal,
};

#endif // TRAP_H