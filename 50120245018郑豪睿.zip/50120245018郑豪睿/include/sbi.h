#ifndef SBI_H
#define SBI_H

#include "types.h"

void console_putchar(int);
int console_getchar();
void shutdown();
void sbi_set_timer(uint64 stime_value);  // 新增：设置定时器

#endif // SBI_H