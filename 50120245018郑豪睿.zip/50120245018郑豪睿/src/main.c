#include "print.h"
#include "trap.h"
#include "riscv.h"

extern void _start();

// 测试用例1：非法指令
void test_illegal_inst() {
    print_string("\n=== Testing Illegal Instruction ===\n");
    asm volatile(".word 0x00000000");
    print_string("Illegal instruction test passed!\n");
}

// 测试用例2：断点
void test_breakpoint() {
    print_string("\n=== Testing Breakpoint ===\n");
    asm volatile("ebreak");
    print_string("Breakpoint test passed!\n");
}

// 测试用例3：加载地址未对齐
void test_load_misaligned() {
    print_string("\n=== Testing Load Address Misaligned ===\n");
    char buf[8] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};
    uint64 *p = (uint64*)(buf + 1);
    uint64 val = *p;
    print_string("Load misaligned test passed!\n");
}

// 测试用例4：存储地址未对齐
void test_store_misaligned() {
    print_string("\n=== Testing Store Address Misaligned ===\n");
    char buf[8] = {0};
    uint64 *p = (uint64*)(buf + 1);
    *p = 0x1122334455667788;
    print_string("Store misaligned test passed!\n");
}

// 运行所有异常测试
void run_all_exception_tests() {
    print_string("\n\n========== Running All Exception Tests ==========\n");
    
    test_illegal_inst();
    process_pending_exceptions();  // 处理测试产生的异常
    
    test_breakpoint();
    process_pending_exceptions();  // 处理测试产生的异常
    
    test_load_misaligned();
    process_pending_exceptions();  // 处理测试产生的异常
    
    test_store_misaligned();
    process_pending_exceptions();  // 处理测试产生的异常
    
    print_string("\n========== Exception Tests Completed ==========\n");
}

void main(void) {
    print_string("RISC-V Bootloader\n");
    print_string("Hello XOS!\n");
    print_string("PLIC initialized, UART IRQ 10 enabled\n");
    print_string("Timer initialized, interval: ~1s\n");
    print_string("Interrupt system initialized\n");

    // 初始化中断处理系统
    init_interrupt();

    // 运行所有异常测试
    run_all_exception_tests();
    
    // 测试中断
    print_string("\n\nEntering interrupt test mode...\n");
    print_string("Timer interrupts will occur every ~1 second\n");
    print_string("Press Ctrl+A then X to exit QEMU\n");

    uint64 last_tick = 0;
    
    // 进入主循环
    while (1) {
        // 处理待打印的异常
        process_pending_exceptions();
        
        // 打印时钟滴答（每秒一次）
        if (timer_ticks != last_tick) {
            last_tick = timer_ticks;
            print_string("\n[Timer] Tick ");
            
            // 简单的数字打印
            char buf[16];
            int i = 0;
            uint64 t = timer_ticks;
            do {
                buf[i++] = '0' + (t % 10);
                t /= 10;
            } while (t > 0);
            while (i > 0) {
                print_char(buf[--i]);
            }
            print_string("\n");
        }
        
        // 等待中断
        asm volatile("wfi");
    }
}