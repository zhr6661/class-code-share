#include "defs.h"
#include "trap.h"

// 异常环形缓冲区
volatile struct exception_info exception_buffer[MAX_EXCEPTIONS];
volatile int exception_head = 0;
volatile int exception_tail = 0;

// 时钟计数器
volatile uint64 timer_ticks = 0;
#define TIMER_INTERVAL 1000000  // 约1秒（QEMU中）

// PLIC寄存器地址（QEMU virt平台）
#define PLIC_BASE 0x0c000000ULL
#define PLIC_PRIORITY (PLIC_BASE + 0x0ULL)
#define PLIC_ENABLE(hart) (PLIC_BASE + 0x2000ULL + (uint64)(hart)*0x100ULL)
#define PLIC_THRESHOLD(hart) (PLIC_BASE + 0x200000ULL + (uint64)(hart)*0x2000ULL)
#define PLIC_CLAIM(hart) (PLIC_BASE + 0x200004ULL + (uint64)(hart)*0x2000ULL)

// UART中断号（QEMU virt平台）
#define UART_IRQ 10

// 安全的MMIO访问宏
#define MMIO_READ32(addr) (*(volatile uint32*)(uintptr)(addr))
#define MMIO_WRITE32(addr, val) (*(volatile uint32*)(uintptr)(addr) = (val))

extern void trap_vector();

// 异常名称数组
static const char* exception_names[] = {
    [InstructionMisaligned] = "Instruction Address Misaligned",
    [InstructionAccessFault] = "Instruction Access Fault",
    [IllegalInstruction] = "Illegal Instruction",
    [Breakpoint] = "Breakpoint",
    [LoadMisaligned] = "Load Address Misaligned",
    [LoadAccessFault] = "Load Access Fault",
    [StoreMisaligned] = "Store/AMO Address Misaligned",
    [StoreAccessFault] = "Store/AMO Access Fault",
    [UserEnvCall] = "Environment Call from U-mode",
    [SupervisorEnvCall] = "Environment Call from S-mode",
    [10] = "Reserved",
    [MachineEnvCall] = "Environment Call from M-mode",
    [InstructionPageFault] = "Instruction Page Fault",
    [LoadPageFault] = "Load Page Fault",
    [14] = "Reserved",
    [StorePageFault] = "Store/AMO Page Fault",
};

// 初始化中断系统
void kernel_trap_init()
{
    // 设置中断向量表
    w_stvec((uint64)trap_vector);
    
    // 初始化PLIC
    plic_init();
    
    // 初始化时钟
    timer_init();
    
    // 使能全局中断
    intr_on();
}

void init_interrupt() {
    kernel_trap_init();
}

// 初始化PLIC
void plic_init()
{
    int hart = 0;
    
    // 设置UART中断优先级
    MMIO_WRITE32(PLIC_PRIORITY + UART_IRQ * 4ULL, 1);
    
    // 使能UART中断
    MMIO_WRITE32(PLIC_ENABLE(hart), (1U << UART_IRQ));
    
    // 设置中断阈值为0
    MMIO_WRITE32(PLIC_THRESHOLD(hart), 0);
    
    // 使能外部中断
    w_sie(r_sie() | SIE_SEIE);
}

// 初始化时钟中断
void timer_init()
{
    // 使能时钟中断
    w_sie(r_sie() | SIE_STIE);
    
    // 设置第一个定时器中断
    timer_set_next();
}

// 设置下一个定时器中断
void timer_set_next()
{
    uint64 now = r_time();
    sbi_set_timer(now + TIMER_INTERVAL);
}

// 获取当前时间（毫秒）
uint64 get_time_ms()
{
    return timer_ticks * 1000;
}

// 时钟中断处理函数（无任何打印）
void timer_handler()
{
    timer_ticks++;
    timer_set_next();
}

// UART中断处理函数（无任何打印）
void uart_handler()
{
    // 只读取字符，不打印
    console_getchar();
}

// 外部中断处理函数（无任何打印）
void external_handler()
{
    int hart = 0;
    int irq = MMIO_READ32(PLIC_CLAIM(hart));
    
    if (irq == UART_IRQ) {
        uart_handler();
    }
    
    // 完成中断处理
    if (irq != 0) {
        MMIO_WRITE32(PLIC_CLAIM(hart), irq);
    }
}

// 将异常信息加入缓冲区（无任何打印）
void record_exception(uint64 cause, uint64 epc)
{
    int next_head = (exception_head + 1) % MAX_EXCEPTIONS;
    if (next_head != exception_tail) {
        exception_buffer[exception_head].cause = cause;
        exception_buffer[exception_head].epc = epc;
        exception_buffer[exception_head].handled = 0;
        exception_head = next_head;
    }
}

// 通用异常处理函数（无任何打印！！！）
void handle_exception(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    
    // 只记录异常，不做任何打印
    record_exception(cause_code, tf->epc);
    
    // 所有异常都跳过当前指令
    tf->epc += 4;
}

// 通用中断处理函数（无任何打印！！！）
void handle_interrupt(struct trapframe *tf) {
    uint64 cause_code = tf->cause & SCAUSE_MASK_ECODE;
    
    switch (cause_code) {
        case SupervisorTimer:
            timer_handler();
            break;
            
        case SupervisorExternal:
            external_handler();
            break;
            
        case SupervisorSoft:
            // 清除软件中断
            w_sip(r_sip() & ~(1L << 1));
            break;
            
        default:
            break;
    }
}

// 中断和异常处理的总入口（无任何打印！！！）
void trap_handler(struct trapframe *tf) {
    if (tf->cause & SCAUSE_MASK_INTERRUPT) {
        handle_interrupt(tf);
    } else {
        handle_exception(tf);
    }
}

void trap(struct trapframe *tf) { 
    trap_handler(tf); 
}

// 在主循环中处理待打印的异常（安全上下文）
void process_pending_exceptions(void)
{
    while (exception_tail != exception_head) {
        volatile struct exception_info *info = &exception_buffer[exception_tail];  // 已修复：添加volatile修饰符
        if (!info->handled) {
            uint64 cause_code = info->cause & SCAUSE_MASK_ECODE;
            
            print_string("\n=== Exception Occurred ===\n");
            if (cause_code < sizeof(exception_names)/sizeof(exception_names[0]) && exception_names[cause_code]) {
                print_string("Type: ");
                print_string(exception_names[cause_code]);
                print_string("\n");
            } else {
                print_string("Type: Unknown Exception\n");
            }
            
            print_string("Resuming execution\n");
            print_string("==========================\n\n");
            
            info->handled = 1;
        }
        exception_tail = (exception_tail + 1) % MAX_EXCEPTIONS;
    }
}

// 空的打印函数，避免编译错误
void print_trapframe(struct trapframe *tf) {}
void print_csr(struct trapframe *tf) {}
void print_regs(struct pushregs *gpr) {}